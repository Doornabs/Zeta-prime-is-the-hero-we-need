# COLLATZ: FALL OF THE PRIMES

A playable Roblox Studio story prototype. Two Luau scripts build the environment and implement the first quest.

## Setup
1. Create a new **Baseplate** place in Roblox Studio.
2. Add a **Script** under **ServerScriptService**, name it `CollatzGame`, and paste in `ServerScriptService_CollatzGame.lua`.
3. Add a **LocalScript** under **StarterPlayer > StarterPlayerScripts**, name it `CollatzClient`, and paste in `StarterPlayerScripts_CollatzClient.lua`.
4. Press **Play** (not just Run). The scripts create the map automatically.

## Story / playable sequence
- Planet Primehold is devastated by Collatz's forces, after his twenty-galaxy campaign to find the Conjecture.
- You play Zeta Prime, last surviving scout of the Composite Guard.
- Speak to Archivist Sigma to learn about the Conjecture.
- Defeat three hostile Collatz drones with the `Pulse Blade` tool (click within range).
- Collect three scattered Proof Fragments.
- Speak to Sigma again to activate the escape portal to the next planet, Residua.
- Enter the portal to complete the episode and see a cliffhanger.

## Notes
- This is a single-place prototype with an episode-end portal. Episode 2 could be built as a separate Roblox place/teleport later.
- Progress persists only for the current server session.
- Server validates tool distance, damage, enemy state, quest progress, and collection range.
- All map geometry is generated in code; replace parts with custom models and animations as needed.
